Building
========
Build and run from this directory. Example:

    gcc ../test_deviceio/ma_test_deviceio.c -o bin/test_deviceio -ldl -lm -lpthread -Wall -Wextra -Wpedantic -std=c89
    ./bin/test_deviceio
    
Output files will be placed in the "res/output" folder.
