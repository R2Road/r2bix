These files split the main library into separate .h and .c files. This is intended for those who prefer separate files
or whose build environment better suits this configuration. The files here are generated from a tool based on the
content in the main miniaudio.h file. Do not edit these files directly. If you want to contribute, please make the
contribution in the main file.

This is not always up to date with the most recent commit in the dev branch, but will usually be up to date with the
master branch.